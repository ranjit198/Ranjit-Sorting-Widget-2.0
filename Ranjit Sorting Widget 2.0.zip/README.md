# Ranjit Sorting Scanner

**Automated consignment scan & sort tool for Pathao Hermes**
Developed by **Ranjit Kapar**

---

## What This Does

This tool runs inside Google Chrome and works on the Pathao processing
page (`hermes.pathaointernal.com/orders/processing/*`). When you scan a
Consignment ID, it automatically finds the matching row on the page and
clicks the correct **"STICKER PRINT & AT SORTING"** button for you —
no manual searching or clicking required.

---

## Installation

This is a one-time setup. It takes about 30 seconds.

1. Extract this folder anywhere on your computer (Desktop, Downloads — doesn't matter).
2. Double-click **`Install.bat`**.
3. Follow the on-screen steps in the setup window. It will:
   - Copy the extension files to your computer
   - Open Chrome's Extensions page automatically
   - Open the installed folder in File Explorer
   - Copy the folder path to your clipboard
4. In the Chrome Extensions page:
   - Turn ON **Developer mode** (top-right corner)
   - Click **Load unpacked**
   - In the folder picker, press **Ctrl+L** to select the address bar,
     then **Ctrl+V** to paste the path, then press **Enter**
5. Done. The extension is now installed in your normal Chrome browser.

> No separate app, no special Chrome shortcut, no re-login required.
> This works exactly like your regular Chrome — just with the scanner
> built in.

---

## Daily Use

1. Open Chrome as usual and go to the Pathao **orders/processing** page.
2. The scanner widget appears automatically in the top-right corner.
3. Click the red **"Scanner OFF"** button to turn it **ON**.
4. Scan a Consignment ID — the matching row is found and the correct
   sticker/sort button is clicked automatically.

---

## Widget Features

| Feature | How to use it |
|---|---|
| **Move the widget** | Click and hold the logo banner at the top, then drag it anywhere on screen |
| **Resize the widget** | Click and drag the small handle in the bottom-right corner |
| **Minimize/Expand** | Click the **—** button in the top-right of the widget to collapse it to just the header; click again (**▢**) to expand |
| **Remembers position & size** | Wherever you leave the widget, it stays there — even after refreshing the page |

---

## Notes

- Works only in **Google Chrome**. Not compatible with Firefox, Edge, or Safari.
- Runs entirely offline/local — it only reads the current page and does
  not send any data anywhere.
- All credit for this tool belongs to **Ranjit Kapar**.

---

## Troubleshooting

| Problem | Solution |
|---|---|
| Widget doesn't appear | Refresh the Pathao processing page. If it still doesn't show, check that the extension is enabled in `chrome://extensions/` |
| "Consignment Not Found" on a valid scan | Make sure the page has fully loaded and the ID was scanned correctly |
| Resize handle doesn't respond | Hover precisely over the bottom-right corner of the widget until the cursor changes to a resize arrow, then click and drag |
| Widget position looks off after a screen/resolution change | Drag the widget back into view — it will automatically stay on-screen going forward |
| Extension stopped working after an update | Go to `chrome://extensions/`, click the reload icon on the Ranjit Sorting Scanner card, then refresh the Pathao page |
