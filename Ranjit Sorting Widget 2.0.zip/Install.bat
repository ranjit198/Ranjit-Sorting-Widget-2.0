@echo off
setlocal EnableDelayedExpansion
title Ranjit Sorting Scanner - Setup Wizard
color 0A
mode con: cols=80 lines=32

cls
echo.
echo    ############################################################
echo    #                                                          #
echo    #             RANJIT SORTING SCANNER  v1.0                 #
echo    #         Automated Consignment Sort ^& Print Tool          #
echo    #                                                          #
echo    #                 Developed by Ranjit Kapar                #
echo    #                                                          #
echo    ############################################################
echo.
echo.
echo    Welcome! This setup will install the scanner extension
echo    into your Chrome browser. The process takes about 30 seconds.
echo.
echo    --------------------------------------------------------
pause
cls

set INSTALL_DIR=%LOCALAPPDATA%\RanjitSortingScanner

echo.
echo    [1/3] Preparing installation directory...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%" >nul 2>nul
timeout /t 1 /nobreak >nul
echo          Done.
echo.

echo    [2/3] Copying extension files...
xcopy /E /I /Y "%~dp0extension" "%INSTALL_DIR%" >nul
timeout /t 1 /nobreak >nul
echo          Done.
echo.

echo    [3/3] Finalizing installation...
timeout /t 1 /nobreak >nul
echo          Done.
echo.
echo    --------------------------------------------------------
echo     Installation complete.
echo.
echo     Installed to:
echo     %INSTALL_DIR%
echo    --------------------------------------------------------
echo.
pause
cls

echo.
echo    ############################################################
echo    #                  FINAL SETUP STEP                       #
echo    ############################################################
echo.
echo    Chrome will now open to the Extensions page. Please follow
echo    these steps (one-time only):
echo.
echo      1.  Toggle "Developer mode" ON  (top-right corner)
echo      2.  Click "Load unpacked"
echo      3.  In the folder window that opens, press Ctrl+L
echo          (this selects the address bar)
echo      4.  Press Ctrl+V to paste the path, then press Enter
echo          (the path below has been copied to your clipboard)
echo.
echo            %INSTALL_DIR%
echo.
echo    Once loaded, the scanner will activate automatically on
echo    the Pathao processing page.
echo.
echo    --------------------------------------------------------
echo %INSTALL_DIR%| clip
pause

set CHROME_EXE="C:\Program Files\Google\Chrome\Application\chrome.exe"
if not exist %CHROME_EXE% set CHROME_EXE="C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
if not exist %CHROME_EXE% set CHROME_EXE="%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"

if exist %CHROME_EXE% (
    start "" %CHROME_EXE% "chrome://extensions/"
) else (
    echo.
    echo    Chrome could not be located automatically.
    echo    Please open Chrome manually and navigate to: chrome://extensions/
)

start "" explorer "%INSTALL_DIR%"

cls
echo.
echo    ############################################################
echo    #                                                          #
echo    #                  SETUP COMPLETE                         #
echo    #                                                          #
echo    #     Open the Pathao processing page in Chrome and        #
echo    #     the scanner widget will appear automatically.        #
echo    #                                                          #
echo    #                                                          #
echo    #               Ranjit Sorting Scanner v1.0                #
echo    #                  by Ranjit Kapar                         #
echo    #                                                          #
echo    ############################################################
echo.
pause
