// ===================================================================
// Ranjit Sorting Scanner - Chrome Extension
// Original logic by Ranjit Kapar (Tampermonkey v19)
// Converted to standalone Chrome Extension - same exact behaviour
//
// Security notes:
// - No remote code execution: only static, bundled JS runs (no eval,
//   no Function(), no fetching/loading of external scripts).
// - No network requests of any kind — fully local/offline.
// - Only ever reads/writes within this single page's DOM; never
//   transmits page data anywhere.
// - Runs only on the exact Pathao processing URL (see manifest.json).
// - All dynamic text inserted via textContent (never innerHTML), so
//   scanned input or page content can never be interpreted as HTML/JS.
// - Defensive null/type checks throughout to avoid crashes on
//   unexpected page structure.
// - Widget position is saved only to this browser's local storage
//   (scoped to this page's origin) — never sent anywhere.
// ===================================================================

(function () {
    'use strict';

    // Prevent duplicate injection
    if (window.ranjitScannerLoaded) return;
    window.ranjitScannerLoaded = true;

    // ===== PAGE TYPE CHECK =====
    // The widget should only appear on a specific consignment detail
    // page (e.g. /orders/processing/269105/unprocessed), not on the
    // general processing list page (/orders/processing). We detect
    // this by checking for a numeric ID segment right after
    // "processing/" in the URL path.
    const DETAIL_PAGE_PATTERN = /\/orders\/processing\/\d+/;

    function isDetailPage() {
        return DETAIL_PAGE_PATTERN.test(window.location.pathname);
    }

    // ===== THEME (Pathao brand colors) =====
    const THEME = {
        accent: "#E94E2C",      // Pathao red-orange
        accentDark: "#C73E1F",  // darker shade for hover/active
        black: "#1a1a1a",
        white: "#ffffff",
        success: "#198754",
        warning: "#ffc107",
        danger: "#dc3545",
        info: "#0d6efd",
        grey: "#888888",
    };

    const POSITION_KEY = "ranjitScannerPosition";
    const COLLAPSED_KEY = "ranjitScannerCollapsed";
    const WIDTH_KEY = "ranjitScannerWidth";
    const COMMA_MODE_KEY = "ranjitScannerCommaMode";
    const MIN_WIDTH = 200;
    const MAX_WIDTH = 480;
    const DEFAULT_WIDTH = 260;

    let widgetInjected = false;

    function initWidget() {
    if (widgetInjected) return;
    widgetInjected = true;

    let lastScan = "";
    let scannerEnabled = false;
    let statusTimeout = null;
    let isProcessing = false;
    let isCollapsed = false;

    // Drag state
    let isDragging = false;
    let dragOffsetX = 0;
    let dragOffsetY = 0;

    // ===== LOAD SAVED POSITION/STATE =====
    function loadSavedPosition() {
        try {
            const raw = localStorage.getItem(POSITION_KEY);
            if (!raw) return null;
            const pos = JSON.parse(raw);
            if (typeof pos.top === "number" && typeof pos.left === "number") {
                return pos;
            }
        } catch (e) {
            // Corrupt/missing data - ignore and use default position
        }
        return null;
    }

    function savePosition(top, left) {
        try {
            localStorage.setItem(POSITION_KEY, JSON.stringify({ top, left }));
        } catch (e) {
            // Storage might be full/disabled - fail silently, not critical
        }
    }

    function loadCollapsedState() {
        try {
            return localStorage.getItem(COLLAPSED_KEY) === "1";
        } catch (e) {
            return false;
        }
    }

    function saveCollapsedState(collapsed) {
        try {
            localStorage.setItem(COLLAPSED_KEY, collapsed ? "1" : "0");
        } catch (e) {
            // Non-critical
        }
    }

    function loadSavedWidth() {
        try {
            const raw = localStorage.getItem(WIDTH_KEY);
            const w = parseInt(raw, 10);
            if (!isNaN(w) && w >= MIN_WIDTH && w <= MAX_WIDTH) return w;
        } catch (e) {
            // Corrupt/missing - use default
        }
        return DEFAULT_WIDTH;
    }

    function saveWidth(w) {
        try {
            localStorage.setItem(WIDTH_KEY, String(w));
        } catch (e) {
            // Non-critical
        }
    }

    // ===== CONTAINER (single draggable wrapper for everything) =====
    const container = document.createElement("div");
    container.id = "ranjit-scanner-container";

    Object.assign(container.style, {
        position: "fixed",
        top: "20px",
        right: "20px",
        width: loadSavedWidth() + "px",
        zIndex: "2147483647", // max safe z-index, stays above page content
        fontFamily: "Segoe UI, Arial, sans-serif",
        userSelect: "none",
        background: THEME.white,
        borderRadius: "10px",
        boxShadow: "0 4px 16px rgba(0,0,0,0.25)",
        overflow: "hidden",
        border: "1px solid #eee",
    });

    // ===== HEADER BAR (full-width logo banner, draggable, with minimize) =====
    const headerBar = document.createElement("div");
    Object.assign(headerBar.style, {
        position: "relative",
        cursor: "grab",
        background: THEME.white,
        borderBottom: "1px solid #eee",
        padding: "6px 0",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
    });

    const headerLogo = document.createElement("img");
    headerLogo.src = chrome.runtime.getURL("icons/pathao-logo.png");
    headerLogo.alt = "Pathao Parcel";
    Object.assign(headerLogo.style, {
        width: "55%",
        height: "auto",
        display: "block",
        pointerEvents: "none",
    });

    const minimizeBtn = document.createElement("span");
    Object.assign(minimizeBtn.style, {
        position: "absolute",
        top: "4px",
        right: "8px",
        color: THEME.black,
        fontSize: "14px",
        fontWeight: "bold",
        cursor: "pointer",
        padding: "2px 6px",
        lineHeight: "1",
        background: "rgba(0,0,0,0.08)",
        borderRadius: "4px",
    });
    minimizeBtn.textContent = "—";
    minimizeBtn.title = "Minimize";

    headerBar.appendChild(headerLogo);
    headerBar.appendChild(minimizeBtn);
    container.appendChild(headerBar);

    // ===== BODY (everything that collapses) =====
    const body = document.createElement("div");
    Object.assign(body.style, {
        padding: "10px",
    });
    container.appendChild(body);

    // ===== STATUS BOX (toggle button) =====
    const box = document.createElement("div");
    box.id = "ranjit-scanner-box";

    Object.assign(box.style, {
        background: THEME.accent,
        color: THEME.white,
        padding: "12px 16px",
        borderRadius: "8px",
        fontWeight: "bold",
        fontSize: "15px",
        cursor: "pointer",
        textAlign: "center",
        transition: "background 0.15s ease",
    });

    box.textContent = "⛔ Scanner OFF";
    body.appendChild(box);

    // ===== CREDIT TAG =====
    const credit = document.createElement("div");
    Object.assign(credit.style, {
        fontSize: "10px",
        color: THEME.grey,
        textAlign: "center",
        padding: "4px 0 0",
    });
    credit.textContent = "by Ranjit Kapar";
    body.appendChild(credit);

    // ===== COMMA MODE TOGGLE (small button) =====
    // ON: scan like "3000,DP271026EBUQQ8,CR1" -> uses the text between
    // the first and second comma ("DP271026EBUQQ8") as the consignment ID.
    let commaMode = false;
    try {
        commaMode = localStorage.getItem(COMMA_MODE_KEY) === "1";
    } catch (e) {}

    const commaBtn = document.createElement("div");
    Object.assign(commaBtn.style, {
        marginTop: "6px",
        padding: "4px 8px",
        borderRadius: "6px",
        fontSize: "11px",
        fontWeight: "bold",
        textAlign: "center",
        cursor: "pointer",
        border: "1px solid #ccc",
    });
    commaBtn.title = "When ON: scans like 3000,CID,CR1 will use the CID between the two commas";

    function updateCommaBtn() {
        commaBtn.textContent = commaMode ? "QR Scan Mode Activated" : "Active QR Scan Mode";
        commaBtn.style.background = commaMode ? THEME.black : THEME.white;
        commaBtn.style.color = commaMode ? THEME.white : THEME.black;
    }
    updateCommaBtn();

    commaBtn.addEventListener("click", () => {
        commaMode = !commaMode;
        updateCommaBtn();
        try {
            localStorage.setItem(COMMA_MODE_KEY, commaMode ? "1" : "0");
        } catch (e) {}
        if (scannerEnabled) setTimeout(() => input.focus(), 50);
    });
    body.appendChild(commaBtn);

    // ===== INPUT =====
    const input = document.createElement("input");
    input.type = "text";
    input.placeholder = "SCAN CID HERE";
    input.autocomplete = "off";
    input.spellcheck = false;

    Object.assign(input.style, {
        width: "100%",
        height: "42px",
        fontSize: "18px",
        padding: "5px 10px",
        border: `3px solid ${THEME.black}`,
        borderRadius: "8px",
        background: THEME.white,
        color: THEME.black,
        display: "none",
        outline: "none",
        boxSizing: "border-box",
        marginTop: "8px",
    });

    body.appendChild(input);

    // ===== RESIZE HANDLE (bottom-right corner) =====
    const resizeHandle = document.createElement("div");
    Object.assign(resizeHandle.style, {
        position: "absolute",
        width: "22px",
        height: "22px",
        right: "0",
        bottom: "0",
        cursor: "nwse-resize",
        zIndex: "10",
        background:
            "linear-gradient(135deg, transparent 0%, transparent 45%, #999 45%, #999 55%, transparent 55%, transparent 65%, #999 65%, #999 75%, transparent 75%, transparent 85%, #999 85%, #999 95%, transparent 95%)",
    });
    container.appendChild(resizeHandle);

    document.body.appendChild(container);

    // ===== APPLY SAVED POSITION (if any) =====
    const savedPos = loadSavedPosition();
    if (savedPos) {
        // Clamp into view in case screen size changed since last save
        requestAnimationFrame(() => {
            const maxLeft = window.innerWidth - container.offsetWidth;
            const maxTop = window.innerHeight - container.offsetHeight;
            const left = Math.max(0, Math.min(savedPos.left, Math.max(0, maxLeft)));
            const top = Math.max(0, Math.min(savedPos.top, Math.max(0, maxTop)));
            container.style.left = left + "px";
            container.style.top = top + "px";
            container.style.right = "auto";
        });
    }

    // ===== RESIZE LOGIC =====
    let isResizing = false;
    let resizeStartX = 0;
    let resizeStartWidth = 0;
    let resizeStartLeft = 0;

    resizeHandle.addEventListener("mousedown", (e) => {
        isResizing = true;
        resizeStartX = e.clientX;
        resizeStartWidth = container.getBoundingClientRect().width;
        resizeStartLeft = container.getBoundingClientRect().left;

        // Pin the widget by its left edge during resize so growing/
        // shrinking always happens from the right side, predictably -
        // this also fixes resize not visibly working when the widget
        // was still anchored via "right" instead of "left".
        container.style.left = resizeStartLeft + "px";
        container.style.right = "auto";

        e.preventDefault();
        e.stopPropagation();
    });

    document.addEventListener("mousemove", (e) => {
        if (!isResizing) return;
        const delta = e.clientX - resizeStartX;
        let newWidth = resizeStartWidth + delta;
        newWidth = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, newWidth));

        // Keep widget fully on-screen while resizing
        const maxWidthForPosition = window.innerWidth - resizeStartLeft;
        newWidth = Math.min(newWidth, maxWidthForPosition);

        container.style.width = newWidth + "px";
    });

    document.addEventListener("mouseup", () => {
        if (isResizing) {
            isResizing = false;
            saveWidth(Math.round(container.getBoundingClientRect().width));
            savePosition(container.getBoundingClientRect().top, container.getBoundingClientRect().left);
        }
    });

    // ===== APPLY SAVED COLLAPSED STATE =====
    isCollapsed = loadCollapsedState();

    function applyCollapsedUI() {
        body.style.display = isCollapsed ? "none" : "block";
        resizeHandle.style.display = isCollapsed ? "none" : "block";
        minimizeBtn.textContent = isCollapsed ? "▢" : "—";
        minimizeBtn.title = isCollapsed ? "Expand" : "Minimize";
    }
    applyCollapsedUI();

    minimizeBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        isCollapsed = !isCollapsed;
        applyCollapsedUI();
        saveCollapsedState(isCollapsed);
    });

    // ===== DRAG LOGIC =====
    // Dragging is scoped only to the header bar, so accidental drags
    // while clicking the toggle/input never happen. Position is kept
    // fully on-screen at all times, and saved so it persists across
    // page reloads.
    headerBar.addEventListener("mousedown", (e) => {
        if (e.target === minimizeBtn) return;
        isDragging = true;
        const rect = container.getBoundingClientRect();
        dragOffsetX = e.clientX - rect.left;
        dragOffsetY = e.clientY - rect.top;
        headerBar.style.cursor = "grabbing";
        e.preventDefault();
    });

    document.addEventListener("mousemove", (e) => {
        if (!isDragging) return;

        let newLeft = e.clientX - dragOffsetX;
        let newTop = e.clientY - dragOffsetY;

        const maxLeft = window.innerWidth - container.offsetWidth;
        const maxTop = window.innerHeight - container.offsetHeight;

        newLeft = Math.max(0, Math.min(newLeft, maxLeft));
        newTop = Math.max(0, Math.min(newTop, maxTop));

        container.style.left = newLeft + "px";
        container.style.top = newTop + "px";
        container.style.right = "auto";
    });

    document.addEventListener("mouseup", () => {
        if (isDragging) {
            isDragging = false;
            headerBar.style.cursor = "grab";

            // Save final position
            const rect = container.getBoundingClientRect();
            savePosition(rect.top, rect.left);
        }
    });

    // Keep widget on-screen if the window is resized
    window.addEventListener("resize", () => {
        const rect = container.getBoundingClientRect();
        const maxLeft = window.innerWidth - container.offsetWidth;
        const maxTop = window.innerHeight - container.offsetHeight;

        if (rect.left > maxLeft) container.style.left = Math.max(0, maxLeft) + "px";
        if (rect.top > maxTop) container.style.top = Math.max(0, maxTop) + "px";
    });

    // ===== UPDATE UI =====
    function updateScannerUI() {
        if (scannerEnabled) {
            box.textContent = "✅ Scanner ON";
            box.style.background = THEME.success;
            input.style.display = "block";
            setTimeout(() => input.focus(), 100);
        } else {
            box.textContent = "⛔ Scanner OFF";
            box.style.background = THEME.accent;
            input.style.display = "none";
        }
    }

    // ===== TOGGLE =====
    box.addEventListener("click", () => {
        scannerEnabled = !scannerEnabled;
        updateScannerUI();
    });

    // ===== STATUS =====
    function status(text, color) {
        clearTimeout(statusTimeout);
        box.textContent = text;
        box.style.background = color || THEME.info;
        statusTimeout = setTimeout(() => {
            updateScannerUI();
        }, 1500);
    }

    // ===== AUTO FOCUS =====
    setInterval(() => {
        if (
            scannerEnabled &&
            !isCollapsed &&
            document.activeElement !== input &&
            document.activeElement &&
            !["INPUT", "TEXTAREA"].includes(document.activeElement.tagName)
        ) {
            input.focus();
        }
    }, 1000);

    // ===== NORMALIZE =====
    // Only ever reads text already visible on the page; never executes
    // or evaluates it as code in any way.
    function norm(t) {
        return (t || "")
            .toString()
            .toLowerCase()
            .trim()
            .replace(/\s+/g, "")
            .replace(/-/g, "");
    }

    // ===== SAFE CLICK =====
    function smartClick(el) {
        if (!el || typeof el.dispatchEvent !== "function") return;
        if (typeof el.scrollIntoView === "function") {
            el.scrollIntoView({ behavior: "smooth", block: "center" });
        }
        setTimeout(() => {
            el.dispatchEvent(
                new MouseEvent("click", { bubbles: true, cancelable: true, view: window })
            );
        }, 200);
    }

    // ===== MAIN PROCESS =====
    function process(scanValue) {
        if (isProcessing) return;
        isProcessing = true;

        // Comma Mode: "3000,DP271026EBUQQ8,CR1" -> "DP271026EBUQQ8"
        let rawValue = scanValue;
        if (commaMode && typeof rawValue === "string") {
            const parts = rawValue.split(",");
            if (parts.length >= 3) rawValue = parts[1];
        }

        const code = norm(rawValue);

        // Basic input validation - reject anything implausible.
        // Caps length to avoid pathological inputs being scanned
        // into the DOM search loop below.
        if (!code || code.length < 5 || code.length > 64) {
            status("❌ Invalid", THEME.danger);
            isProcessing = false;
            return;
        }

        if (code === lastScan) {
            status("⚠️ Duplicate", THEME.warning);
            isProcessing = false;
            return;
        }

        status("🔍 Searching...", THEME.info);

        const allCells = document.querySelectorAll("td, div, span");
        let found = false;

        for (const cell of allCells) {
            // Never trust/execute cell content - only compare as plain text
            const text = norm(cell.innerText);
            if (text !== code) continue;

            found = true;

            cell.style.background = "#ffeb3b";
            cell.style.outline = "2px solid red";

            let row = cell.closest("tr");

            if (!row) {
                let current = cell;
                for (let i = 0; i < 10; i++) {
                    if (!current) break;
                    const btns = current.querySelectorAll("button, .btn");
                    if (btns.length > 0) {
                        row = current;
                        break;
                    }
                    current = current.parentElement;
                }
            }

            if (!row) {
                status("❌ Row Not Found", THEME.danger);
                isProcessing = false;
                return;
            }

            row.style.background = "#fff3cd";

            const buttons = row.querySelectorAll("button, .btn");
            let targetBtn = null;

            for (const btn of buttons) {
                const btnText = norm(btn.innerText || btn.textContent || "");
                if (btnText.includes("sticker") && btnText.includes("sorting")) {
                    targetBtn = btn;
                    break;
                }
            }

            if (!targetBtn) {
                status("❌ Sort Button Missing", THEME.danger);
                isProcessing = false;
                return;
            }

            targetBtn.style.outline = "4px solid lime";
            lastScan = code;
            smartClick(targetBtn);
            status("✅ Correct Sorting Clicked", THEME.success);
            isProcessing = false;
            return;
        }

        if (!found) {
            status("❌ Consignment Not Found", THEME.danger);
        }

        isProcessing = false;
    }

    // ===== ENTER KEY =====
    input.addEventListener("keydown", function (e) {
        if (!scannerEnabled) return;

        if (e.key === "Enter") {
            e.preventDefault();
            const value = input.value.trim();
            input.value = "";
            process(value);
            setTimeout(() => input.focus(), 100);
        }
    });

    } // end of initWidget()

    // ===== WATCH FOR NAVIGATION (SPA-style URL changes) =====
    // Pathao's app may change the URL (e.g. from the processing list to
    // a specific consignment detail page) without a full page reload.
    // We poll the URL periodically and inject the widget the moment we
    // land on a qualifying detail page.
    let lastCheckedPath = "";

    function checkPageAndInit() {
        if (window.location.pathname === lastCheckedPath) return;
        lastCheckedPath = window.location.pathname;

        if (isDetailPage()) {
            initWidget();
        }
    }

    checkPageAndInit();
    setInterval(checkPageAndInit, 1000);

})();
